select * from olist_customers_dataset;
select * from olist_geolocation_dataset;

-- how many orders in each date
select * from olist_orders_dataset;
select
date(order_purchase_timestamp),
count(*)
from olist_orders_dataset
group by date(order_purchase_timestamp)
order by count(*) desc ;

-- count of customers by city and state
select * from olist_customers_dataset;
select
customer_city, customer_state, count(*) as city_count
from olist_customers_dataset
group by customer_city, customer_state
order by city_count desc;

-- count of each product order
select * from olist_products_dataset;
select * from olist_order_items_dataset;
select
p.product_category_name,
count(*) as count_of_product
from olist_products_dataset p
inner join olist_order_items_dataset oi on p.product_id = oi.product_id
group by p.product_category_name
order by count_of_product desc;

-- difference between order estimated and delivered date
select * from olist_orders_dataset;
select
order_id, order_status,
order_delivered_customer_date,
order_estimated_delivery_date,
datediff(
cast(order_estimated_delivery_date as datetime),
cast(order_delivered_customer_date as datetime)) as diff_in_days
-- datediff indicates the difference in to dates
-- cast can temproraly converts string or text to date
from olist_orders_dataset
where order_status = 'delivered';

-- find which products are delivered and not got any delivered date
select * from olist_orders_dataset;
select
order_id, order_status,
order_purchase_timestamp,
order_delivered_customer_date
from olist_orders_dataset
where order_status = 'delivered' and
cast(order_delivered_customer_date as datetime) is null;

-- count of above query
SELECT
    (order_delivered_customer_date IS NULL OR order_delivered_customer_date = '') AS is_missing,
    COUNT(*) AS total_orders
FROM olist_orders_dataset
GROUP BY is_missing;

-- Checks which items were recorded as delivered before they were even purchased.
select * from olist_orders_dataset;
select
order_id, order_status, order_purchase_timestamp, order_delivered_customer_date
from olist_orders_dataset
where
order_status = 'delivered' and
cast(order_delivered_customer_date as datetime) < cast(order_purchase_timestamp as datetime);

-- Calculates the breakdown of order statuses and computes the percentage of canceled orders using a subquery.
select
order_status,
count(*) as order_count,
round(count(*) * 100.0 / (select count(*) from olist_orders_dataset),2 ) as percentage_share
from olist_orders_dataset
group by order_status
order by order_count desc;

-- Analyzes transaction volume and average basket size per payment method.
select * from olist_order_payments_dataset;
select
payment_type,
count(distinct order_id) as total_orders,
round(avg(payment_value), 2) as average_payment_value,
round(sum(payment_value), 2) as total_revenue
from olist_order_payments_dataset
group by payment_type
order by total_orders desc;

-- Uses a subquery to aggregate orders per unique customer ID and segments them into retention tiers.
select * from olist_customers_dataset;
SELECT 
    order_count_tier,
    COUNT(*) AS customer_count
FROM (
    SELECT 
        c.customer_unique_id,
        COUNT(o.order_id) AS total_orders,
        CASE 
            WHEN COUNT(o.order_id) = 1 THEN '1 Order (One-Time)'
            ELSE '2+ Orders (Repeat)'
        END AS order_count_tier
    FROM olist_customers_dataset c
    JOIN olist_orders_dataset o ON c.customer_id = o.customer_id
    GROUP BY c.customer_unique_id
) sub
GROUP BY order_count_tier;

-- Calculates fulfillment discrepancies between estimated and actual delivery dates grouped by state.
select * from olist_orders_dataset;
select * from olist_geolocation_dataset;
SELECT 
    c.customer_state,
    ROUND(AVG(DATEDIFF(CAST(o.order_delivered_customer_date AS DATETIME), CAST(o.order_estimated_delivery_date AS DATETIME))), 1) AS avg_delay_days
FROM olist_orders_dataset o
JOIN olist_customers_dataset c ON o.customer_id = c.customer_id
WHERE o.order_status = 'delivered' 
  AND o.order_delivered_customer_date IS NOT NULL 
  AND o.order_estimated_delivery_date IS NOT NULL
GROUP BY c.customer_state
ORDER BY avg_delay_days DESC;